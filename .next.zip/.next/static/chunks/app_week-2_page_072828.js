(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_week-2_page_072828.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_week-2_page_072828.js",
  "chunks": [
    "static/chunks/_e156e7._.js"
  ],
  "source": "dynamic"
});
